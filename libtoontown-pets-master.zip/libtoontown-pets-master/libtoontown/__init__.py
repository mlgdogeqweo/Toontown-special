from .pets.CPetBrain import CPetBrain
from .pets.CPetChase import CPetChase
from .pets.CPetFlee import CPetFlee
