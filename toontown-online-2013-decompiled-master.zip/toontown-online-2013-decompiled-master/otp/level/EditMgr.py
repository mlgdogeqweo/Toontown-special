import EditMgrBase

class EditMgr(EditMgrBase.EditMgrBase):
    pass
