NonErrorExitStateStart = 100
ExitPurchase = 100
ExitSetParentPassword = 101
ExitEnableChat = 102
ExitTimeExpired = 103
ExitUpsell = 104
NonErrorExitStateEnd = 199
