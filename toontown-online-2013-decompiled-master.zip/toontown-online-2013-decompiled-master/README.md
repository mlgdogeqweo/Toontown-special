# toontown-online-2013-decompiled
Reverse-engineered client & server source code from Disney's Toontown Online.

Most, if not all, client source code was reverse-engineered from the final production build of Disney's Toontown Online (sv1.0.47.38).

Server source code was reverse-engineered from various Toontown Online clients.

These files are provided as-is with absolutely no warranty, or licensing of any kind. It should be noted that the Toontown Online assets are still the property of The Walt Disney Company and as such should only be used for reference purposes.
