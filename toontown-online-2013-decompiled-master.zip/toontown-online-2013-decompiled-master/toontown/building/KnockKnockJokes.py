from toontown.toonbase import TTLocalizer
KnockKnockJokes = TTLocalizer.KnockKnockJokes
KnockKnockContestJokes = TTLocalizer.KnockKnockContestJokes
