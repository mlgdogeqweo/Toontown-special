

class BanquetTableBase:
    HUNGRY = 1
    DEAD = 0
    EATING = 2
    ANGRY = 3
    HIDDEN = 4
    INACTIVE = 5
