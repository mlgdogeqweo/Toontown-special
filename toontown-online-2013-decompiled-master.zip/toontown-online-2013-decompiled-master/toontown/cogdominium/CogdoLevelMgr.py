from otp.level import LevelMgr
from direct.showbase.PythonUtil import Functor
from toontown.toonbase import ToontownGlobals

class CogdoLevelMgr(LevelMgr.LevelMgr):
    pass
